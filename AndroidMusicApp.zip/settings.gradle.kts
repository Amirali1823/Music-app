rootProject.name = "AndroidMusicApp"
include(":app")
