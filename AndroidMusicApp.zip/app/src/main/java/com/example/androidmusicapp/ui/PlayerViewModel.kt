package com.example.androidmusicapp.ui

import androidx.lifecycle.ViewModel

class PlayerViewModel : ViewModel() {
    // Placeholder for real implementation wired to MusicRepository and MediaBrowser
}
